export interface Scholarship {
    id: number;
    name: string;
    amount: number;
    description: string;
    founder: string;
    deadline: string;
    applyInfo: string;
  }
  