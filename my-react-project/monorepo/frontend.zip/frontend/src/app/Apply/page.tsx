// src/app/Apply/page.tsx

"use client";
//import { useState } from "react";
import { useRouter } from "next/navigation";
import { useState, useEffect } from "react";

export default function ApplyPage() {
  const [selectedOption, setSelectedOption] = useState("quick-apply");
  const [savedScholarships, setSavedScholarships] = useState<string[]>([]);
  const [savedApplications, setSavedApplications] = useState<any[]>([]);
  const router = useRouter();

  // Load saved applications on page load
  // Load saved scholarships and applications on page load
  useEffect(() => {
    const storedScholarships = JSON.parse(
      localStorage.getItem("savedScholarships") || "[]"
    );
    setSavedScholarships(storedScholarships);

    const storedApplications = JSON.parse(
      localStorage.getItem("savedApplications") || "[]"
    );
    setSavedApplications(storedApplications);
  }, []);

  // Scholarship Data
  const scholarships = [
    {
      id: "arizona-excellence",
      name: "Arizona Excellence Scholarship",
      description:
        "Awarded to outstanding students demonstrating academic excellence.",
    },
    {
      id: "engineering-general",
      name: "Engineering General Scholarship",
      description:
        "Scholarship for students pursuing degrees in engineering disciplines.",
    },
    {
      id: "continuing-undergrad",
      name: "Continuing Undergraduate Scholarship",
      description:
        "For current undergraduates who have demonstrated continued academic success.",
    },
    {
      id: "ua-foundation",
      name: "UA Foundation Scholarship",
      description:
        "Funded by the UA Foundation to support student success across all majors.",
    },
    {
      id: "as-government",
      name: "Associated Student Government Scholarship",
      description:
        "Awarded to students who are actively engaged in student government and leadership.",
    },
    {
      id: "hispanic-alumni-club",
      name: "Hispanic Alumni Club Scholarship",
      description:
        "Supporting Hispanic and Latinx students in their pursuit of higher education.",
    },
  ];

  // Function to save a scholarship
  // const handleSaveScholarship = (scholarshipId: string) => {
  //   if (!savedScholarships.includes(scholarshipId)) {
  //     setSavedScholarships([...savedScholarships, scholarshipId]);
  //   }
  // };
  // Function to save a scholarship
  const handleSaveScholarship = (scholarshipId: string) => {
    if (!savedScholarships.includes(scholarshipId)) {
      const updatedScholarships = [...savedScholarships, scholarshipId];
      setSavedScholarships(updatedScholarships);
      localStorage.setItem(
        "savedScholarships",
        JSON.stringify(updatedScholarships)
      );
    }
  };

  // Function to unsave a scholarship
  // const handleUnsaveScholarship = (scholarshipId: string) => {
  //   setSavedScholarships(savedScholarships.filter(id => id !== scholarshipId));
  // };
  // Function to unsave a scholarship
  const handleUnsaveScholarship = (scholarshipId: string) => {
    const updatedScholarships = savedScholarships.filter(
      (id) => id !== scholarshipId
    );
    setSavedScholarships(updatedScholarships);
    localStorage.setItem(
      "savedScholarships",
      JSON.stringify(updatedScholarships)
    );
  };

  // Function to delete application
  const handleDeleteApplication = (scholarshipId: string) => {
    const updatedApplications = savedApplications.filter(
      (app) => app.scholarshipId !== scholarshipId
    );
    setSavedApplications(updatedApplications);
    localStorage.setItem(
      "savedApplications",
      JSON.stringify(updatedApplications)
    );
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      {/* Top Header */}
      <header className="bg-gradient-to-r from-[#AB0520] to-[#9B051F] text-white py-3 px-4 shadow-md">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <img
              src="/images/ua-logo.png"
              alt="UA Logo"
              className="h-10 w-auto"
            />
            <h1 className="text-xl font-bold">UASAMS</h1>
          </div>
          <nav className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <select
                className="text-black px-2 py-1 rounded"
                defaultValue="I am"
              >
                <option>I am</option>
                <option>Student</option>
                <option>Faculty</option>
                <option>Admin</option>
              </select>
              <button className="bg-white text-[#AB0520] px-3 py-1 rounded hover:bg-gray-200 transition">
                Go
              </button>
            </div>
            <button className="bg-white text-[#AB0520] px-3 py-1 rounded hover:bg-gray-200 transition">
              Sign Out
            </button>
          </nav>
        </div>
      </header>

      {/* Main Content Layout */}
      <div className="flex flex-1">
        {/* Left Sidebar */}
        <aside className="w-1/4 bg-white shadow-md p-6">
          <h3 className="text-lg font-semibold mb-4">Menu</h3>
          <ul className="space-y-4">
            <li>
              <button
                className={`w-full text-left px-3 py-2 rounded ${
                  selectedOption === "quick-apply"
                    ? "bg-gray-200"
                    : "hover:bg-gray-100"
                }`}
                onClick={() => setSelectedOption("quick-apply")}
              >
                Quick Apply Scholarships
              </button>
            </li>
            <li>
              <button
                className={`w-full text-left px-3 py-2 rounded ${
                  selectedOption === "saved-scholarships"
                    ? "bg-gray-200"
                    : "hover:bg-gray-100"
                }`}
                onClick={() => setSelectedOption("saved-scholarships")}
              >
                Saved Scholarships
              </button>
            </li>
            <li>
              <button
                className={`w-full text-left px-3 py-2 rounded ${
                  selectedOption === "my-applications"
                    ? "bg-gray-200"
                    : "hover:bg-gray-100"
                }`}
                onClick={() => setSelectedOption("my-applications")}
              >
                My Applications
              </button>
            </li>
            <li>
              <button
                className="w-full text-left px-3 py-2 rounded bg-[#0C234B] text-white hover:bg-blue-700 transition"
                onClick={() => router.push("/Dashboard")}
              >
                Go to Dashboard
              </button>
            </li>
          </ul>
        </aside>

        {/* Right Content */}
        <main className="w-3/4 p-6">
          <h2 className="text-2xl font-semibold mb-6 text-center">
            Apply for Scholarships
          </h2>

          {/* Quick Apply Scholarships */}
          {selectedOption === "quick-apply" && (
            <div className="space-y-6">
              {scholarships.map((scholarship) => {
                const application = savedApplications.find(
                  (app) => app.scholarshipId === scholarship.id
                );

                return (
                  !savedScholarships.includes(scholarship.id) && (
                    <div
                      key={scholarship.id}
                      className="bg-white rounded-lg shadow-md p-6 flex flex-col"
                    >
                      <h3 className="text-lg font-bold mb-2">
                        {scholarship.name}
                      </h3>
                      <p className="text-gray-700 mb-4">
                        {scholarship.description}
                      </p>
                      <div className="flex space-x-3">
                        {application ? (
                          <button
                            className="bg-green-500 text-white py-1.5 px-3 rounded hover:bg-green-700 transition text-sm"
                            onClick={() =>
                              router.push(
                                `/Application?scholarshipId=${scholarship.id}`
                              )
                            }
                          >
                            View/Edit
                          </button>
                        ) : (
                          <button
                            className="bg-[#0C234B] text-white py-1.5 px-3 rounded hover:bg-blue-900 transition text-sm"
                            onClick={() =>
                              router.push(
                                `/Application?scholarshipId=${scholarship.id}`
                              )
                            }
                          >
                            Quick Apply
                          </button>
                        )}
                        <button
                          className="bg-gray-300 text-black py-1.5 px-3 rounded hover:bg-gray-400 transition text-sm"
                          onClick={() => handleSaveScholarship(scholarship.id)}
                        >
                          Save Scholarship
                        </button>
                      </div>
                    </div>
                  )
                );
              })}
            </div>
          )}

          {/* Saved Scholarships */}
          {selectedOption === "saved-scholarships" && (
            <div className="space-y-6">
              {savedScholarships.length > 0 ? (
                savedScholarships.map((scholarshipId) => {
                  const scholarship = scholarships.find(
                    (s) => s.id === scholarshipId
                  );
                  const application = savedApplications.find(
                    (app) => app.scholarshipId === scholarshipId
                  );

                  return scholarship ? (
                    <div
                      key={scholarship.id}
                      className="bg-white rounded-lg shadow-md p-6 flex flex-col"
                    >
                      <h3 className="text-lg font-bold mb-2">
                        {scholarship.name}
                      </h3>
                      <p className="text-gray-700 mb-4">
                        {scholarship.description}
                      </p>
                      <div className="flex space-x-3">
                        {application ? (
                          <button
                            className="bg-green-500 text-white py-1.5 px-3 rounded hover:bg-green-700 transition text-sm"
                            onClick={() =>
                              router.push(
                                `/Application?scholarshipId=${scholarship.id}`
                              )
                            }
                          >
                            View/Edit
                          </button>
                        ) : (
                          <button
                            className="bg-[#0C234B] text-white py-1.5 px-3 rounded hover:bg-blue-900 transition text-sm"
                            onClick={() =>
                              router.push(
                                `/Application?scholarshipId=${scholarship.id}`
                              )
                            }
                          >
                            Quick Apply
                          </button>
                        )}
                        <button
                          className="bg-red-500 text-white py-1.5 px-3 rounded hover:bg-red-700 transition text-sm"
                          onClick={() =>
                            handleUnsaveScholarship(scholarship.id)
                          }
                        >
                          Unsave Scholarship
                        </button>
                      </div>
                    </div>
                  ) : null;
                })
              ) : (
                <p className="text-center text-gray-700">
                  No scholarships saved yet.
                </p>
              )}
            </div>
          )}

          {/* My Applications Section */}
          {selectedOption === "my-applications" && (
            <div className="space-y-6">
              {savedApplications.length > 0 ? (
                savedApplications.map((application, index) => (
                  <div
                    key={index}
                    className="bg-white rounded-lg shadow-md p-6 flex flex-col"
                  >
                    <h3 className="text-lg font-bold mb-2">
                      {scholarships.find(
                        (s) => s.id === application.scholarshipId
                      )?.name || "Unknown Scholarship"}
                      &nbsp;Application
                    </h3>
                    <p className="text-gray-700 mb-4">
                      Application Status: {application.status}
                    </p>
                    <div className="flex space-x-3">
                      <button
                        className="bg-[#0C234B] text-white py-1.5 px-3 rounded hover:bg-blue-900 transition text-sm"
                        onClick={() =>
                          router.push(
                            `/Application?scholarshipId=${application.scholarshipId}`
                          )
                        }
                      >
                        View/Edit
                      </button>
                      <button
                        className="bg-red-500 text-white py-1.5 px-3 rounded hover:bg-red-700 transition text-sm"
                        onClick={() =>
                          handleDeleteApplication(application.scholarshipId)
                        }
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-center text-gray-700">
                  No saved or submitted applications yet.
                </p>
              )}
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
