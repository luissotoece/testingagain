from rest_framework import generics, viewsets, permissions
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.db.models import Avg
from .models import Scholarship
from .serializers import ScholarshipSerializer

# Endpoint to list all scholarships and allow creation (only for admins)
class ScholarshipListCreate(generics.ListCreateAPIView):
    queryset = Scholarship.objects.all()
    serializer_class = ScholarshipSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

    def perform_create(self, serializer):
        # Only staff (admins) can create scholarships.
        if not self.request.user.is_staff:
            raise PermissionError("Only admins can add scholarships.")
        serializer.save()

# Endpoint to retrieve, update, or delete a specific scholarship.
class ScholarshipDetailUpdateDelete(generics.RetrieveUpdateDestroyAPIView):
    queryset = Scholarship.objects.all()
    serializer_class = ScholarshipSerializer
    permission_classes = [permissions.AllowAny]

# Endpoint to filter scholarships by donor.
class ScholarshipsByDonorView(APIView):
    def get(self, request, donor_id):
        qs = Scholarship.objects.filter(donor_id=donor_id, is_active=True)
        serializer = ScholarshipSerializer(qs, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

# ViewSet to expose additional endpoints via DRF router.
class ScholarshipViewSet(viewsets.ModelViewSet):
    queryset = Scholarship.objects.all()
    serializer_class = ScholarshipSerializer
    permission_classes = [permissions.IsAuthenticated]

# Endpoint to generate a report of scholarships.
class ScholarshipReportView(APIView):
    """
    Generates a report of scholarships.
    """
    def get(self, request):
        total = Scholarship.objects.count()
        avg_amount = Scholarship.objects.aggregate(avg=Avg('amount'))['avg']
        active_count = Scholarship.objects.filter(is_active=True).count()
        inactive_count = total - active_count
        report = {
            "total_scholarships": total,
            "average_amount": avg_amount,
            "active_scholarships": active_count,
            "inactive_scholarships": inactive_count,
        }
        return Response(report, status=status.HTTP_200_OK)